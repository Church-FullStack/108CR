import { Component } from '@angular/core';
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'erp';
  count = 0;
  inputText = '';

  test() {
    this.title = "I changed a variable";
    this.inputText = '';
  }
  increaseCount(){
    this.count += 1;
  }
  decreaseCount(){
    this.count -=1;
  }
  tsOverview(){
    var name : string = "Billy Bob";
    var age : number = 92;
    var total: number = 27.4;
    var list: string[] = [name];
    list.push(name);

  }

}
