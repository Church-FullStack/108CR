import { Injectable } from '@angular/core';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  
  private userList = [];

  //inject services using constructor
  constructor() {
    var admin = new User();
    admin.userName = 'Admin';
    admin.userPassword = "123";
    admin.userFirstName = "Admin";
    admin.userLastName = "Lastname";
    this.userList.push(admin);
   }

  saveUser(user: User) {
    this.userList.push(user);
  }

  getAllUsers() {
    return this.userList;
  }
}
