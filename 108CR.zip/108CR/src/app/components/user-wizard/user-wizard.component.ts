import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-user-wizard',
  templateUrl: './user-wizard.component.html',
  styleUrls: ['./user-wizard.component.scss']
})
export class UserWizardComponent implements OnInit {

  model: User = new User();
  retypePass = undefined;
  constructor(private dataServ: DataService) { }

  ngOnInit(): void {
  }
  isAlertVisible = false;

  save() {
    console.log("saving..", this.model, this.retypePass);
    this.dataServ.saveUser(this.model);
    this.model= new User;
    this.retypePass = "";
    this.isAlertVisible = true;
    setTimeout(() => {
      this.isAlertVisible = false;
    },3000);
  }

}
